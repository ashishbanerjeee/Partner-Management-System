﻿using Azure;
using Microsoft.AspNetCore.Mvc;
using Loyal.Models;
using Loyal.Data;
namespace Loyal.Controllers
{
    public class RequestController : Controller
    {
        private readonly Requestcontext _context;
        public RequestController(Requestcontext context)
        {
            _context = context;
        }

        public IActionResult RequestAdd(Request model)
        {
            model.Status = "Pending";
            _context.Requests.Add(model);
            _context.SaveChanges();
            return RedirectToAction("Landing","Home");
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
