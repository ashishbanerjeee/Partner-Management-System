using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Loyal.Models;
using Loyal.Data;
using Microsoft.EntityFrameworkCore;

namespace Loyal.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly PartnerContext _context;
    private readonly Requestcontext _rcontext;
    [ActivatorUtilitiesConstructor]
    public HomeController(ILogger<HomeController> logger, PartnerContext context, Requestcontext rcontext)
    {
        _logger = logger;
        _context = context;
        _rcontext = rcontext;
    }

    public IActionResult Index()
    {
        return View();
    }
    public IActionResult ValidateLogin(Partner model)
    {
        var user = _context.Partners.FirstOrDefault(s => s.Username == model.Username && s.PasswordHash == model.PasswordHash);
        if (user != null)
        {
            if (user.Status != "Activated")
            {
                TempData["Login"] = "User is not active";

                return RedirectToAction("ULanding");
            }
            else
            {
                HttpContext.Session.SetString("Username", $"{model.Username}");
                return RedirectToAction("Landing");
            }
        }
        else
        {
            TempData["Login"] = "Invalid Credentials";
            return RedirectToAction("Login");
        }

    }

    public IActionResult ULanding()
    {
        var dat = _rcontext.Requests.Where(e => e.Username == HttpContext.Session.GetString("Username")).ToList();
        var reason = dat.Select(e => e.Reason).FirstOrDefault();
        TempData["Reason"] = reason;
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    public IActionResult Login()
    {
        return View();
    }

    public IActionResult Requests()
    {
        TempData["Username"] = HttpContext.Session.GetString("Username");
        return View();
    }

    public IActionResult Approved()
    {
        var username = HttpContext.Session.GetString("Username");
        var dat = _rcontext.Requests
                                      .Where(p => p.Status == "Approved" && p.Username == username)
                                      .ToList();
        return View(dat);
    }

    public IActionResult Pending()
    {
        var username = HttpContext.Session.GetString("Username");
        var dat = _rcontext.Requests
                                      .Where(p => p.Status == "Pending" && p.Username == username)
                                      .ToList();
        return View(dat);
    }

    public IActionResult Refuse()
    {
        var username = HttpContext.Session.GetString("Username");
        var dat = _rcontext.Requests
                                      .Where(p => p.Status == "Denied" && p.Username == username)
                                      .ToList();

        return View(dat);
    }



    public IActionResult Landing()
    {
        var username = HttpContext.Session.GetString("Username");
        var dat = _rcontext.Requests
                                      .Where(p => p.Username == username)
                                      .ToList();
        return View(dat);
    }

    public IActionResult Adduser(Partner model)
    {
        var em = _context.Partners.FirstOrDefault(e => e.Email == model.Email);
        var un = _context.Partners.FirstOrDefault(e => e.Username == model.Username);
        var pan = _context.Partners.FirstOrDefault(e => e.Pancard == model.Pancard);
        var adhaar = _context.Partners.FirstOrDefault(e => e.AdhaarCard == model.AdhaarCard);
        if (em == null && un == null && pan == null && adhaar == null)
        {
            model.Status = "InActive";
            _context.Partners.Add(model);
            _context.SaveChanges();
            return RedirectToAction("Login");
        }
        else if (em != null && un != null && adhaar != null && pan == null)
        {

            TempData["UserExists"] = "User already exists.";
            return RedirectToAction("Register");

        }
        else if (em != null || un != null)
        {
            TempData["UserExists"] = "Email and/or Username already exists.";
            return RedirectToAction("Register");
        }

        else if (adhaar != null && pan != null)
        {
            TempData["UserExists"] = "Adhaar Card and Pan Card already exists.";
            return RedirectToAction("Register");
        }

        else if (pan != null)
        {
            TempData["UserExists"] = "Pan Card already exists.";
            return RedirectToAction("Register");
        }
        else
        {
            TempData["UserExists"] = "Adhaar Carde already exist";
            return RedirectToAction("Register");
        }

    }

    public IActionResult Details(int? id)
    {
        if (id != null)
        {
            var dat = _rcontext.Requests.Find(id);
            return View(dat);
        }
        return View();
    }

    public IActionResult RefusedDetails(int? id)
    {
        if (id != null)
        {
            var dat = _rcontext.Requests.Find(id);
            return View(dat);
        }
        return View();
    }
    public IActionResult Register()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
