﻿using Loyal.Data;
using Loyal.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;


namespace Loyal.Controllers
{


    public class AdminController : Controller
    {
        private readonly AdminContext _context;
        private readonly PartnerContext _ucontext;
        private readonly Requestcontext _rcontext;

        [ActivatorUtilitiesConstructor]
        public AdminController(AdminContext context, PartnerContext ucontext, Requestcontext rcontext)
        {
            _ucontext = ucontext;
            _context = context;
            _rcontext = rcontext;
        }
        public IActionResult AdminPage()
        {
            return View();
        }

        public IActionResult AdminLanding()
        {

            return View();
        }

        public IActionResult ApprovedRequest()
        {
            var dat = _rcontext.Requests.Where(s => s.Status == "Approved").ToList();
            return View(dat);
        }

        public IActionResult RefusedRequest()
        {
            var dat = _rcontext.Requests.Where(s => s.Status == "Denied").ToList();
            return View(dat);
        }

        public IActionResult PartnerDetails()
        {
            var data = _ucontext.Partners.ToList();

            return View(data);
        }
        public IActionResult ViewPartner(int? id)
        {

            if (id != null)
            {
                var dat = _ucontext.Partners.Find(id);
                return View(dat);
            }
            return View();
        }

        public IActionResult UpdateStatus(Partner model)
        {
            if (model.Status != "Denied")
            {
                model.Reason = "";
                _ucontext.Partners.Update(model);
                _ucontext.SaveChanges();
            }
            else
            {
                _ucontext.Partners.Update(model);
                _ucontext.SaveChanges();

            }
            return RedirectToAction("PartnerDetails");

        }

        public IActionResult RequestDetails(int? id)
        {
            if (id != null)
            {
                var dat = _rcontext.Requests.Find(id);
                return View(dat);
            }
            return View();
        }

        public IActionResult ApproveRequest(Request model)
        {
            if (model.Status == "Approved")
            {
                model.Reason = "";
            }
            _rcontext.Requests.Update(model);
            _rcontext.SaveChanges();
            return RedirectToAction("ViewRequest");
        }


        public IActionResult ViewRequest()
        {
            var data = _rcontext.Requests.Where(e => e.Status == "Pending").ToList();
            return View(data);
        }

        public IActionResult Details(int? id)
        {
            if (id != null)
            {
                var dat = _rcontext.Requests.Find(id);
                return View(dat);
            }
            return View();
        }

        public IActionResult RefusedDetails(int? id)
        {
            if (id != null)
            {
                var dat = _rcontext.Requests.Find(id);
                return View(dat);
            }
            return View();
        }

        public IActionResult ValidateUser(AdminCred model)
        {
            var user = _context.AdminCredentials.FirstOrDefault(s => s.Username == model.Username && s.Password == model.Password);

            if (user != null)
            {

                return RedirectToAction("AdminLanding");
            }
            else
            {
                TempData["Login"] = "Invalid Credentials";
                return RedirectToAction("AdminPage");
            }

        }

        public IActionResult Logout()
        {
            // Add any logout logic here (e.g., clearing session, cookies, etc.)
            return RedirectToAction("AdminPage");
        }

    }

}
