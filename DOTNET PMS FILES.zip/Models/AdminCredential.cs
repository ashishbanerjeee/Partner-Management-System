﻿using System;
using System.Collections.Generic;

namespace Loyal.Models;

public partial class AdminCredential
{
    public string? Username { get; set; }

    public string? Password { get; set; }
}
