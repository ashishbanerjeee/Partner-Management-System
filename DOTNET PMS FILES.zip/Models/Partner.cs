﻿using System;
using System.Collections.Generic;

namespace Loyal.Models;

public partial class Partner
{
    public int UserId { get; set; }

    public string? Username { get; set; }

    public string? Pancard { get; set; }

    public long AdhaarCard { get; set; }

    public DateTime? CreatedAt { get; set; }

    public string? Status { get; set; }

    public string? Reason { get; set; }

    public string? PasswordHash { get; set; }

    public string? Email { get; set; }
}
