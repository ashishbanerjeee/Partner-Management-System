﻿using System;
using System.Collections.Generic;

namespace Loyal.Models;

public partial class AdminCred
{
    public string? Username { get; set; }

    public string? Password { get; set; }
}
